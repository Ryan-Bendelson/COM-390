﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles

Public Class Form3
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader

    'This function calculates and displays the linear regression coefficients of the data
    Private Function CalcRegression() As Integer
        'CHANGE BELOW LINE FOR CURRENT DEVICE!!
        myConn = New SqlConnection("Data Source = LAPTOP-6G2QDAKE\SQLEXPRESS;
        Initial Catalog = master;
        Integrated Security = SSPI")
        'CHANGE ABOVE LINE FOR CURRENT DEVICE!!

        'Store the number of rows in the regression table as numRows
        Dim numRows = GetNumRows()

        'Query the regression table to prepare the data to be pulled into the Visual Basic application
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT y,x1,x2 FROM regression"
        myConn.Open()
        myReader = myCmd.ExecuteReader()

        'Set up the arrays to store the Y, X1, and X2 variable values
        Dim y = New Double(numRows) {}
        Dim x1 = New Integer(numRows) {}
        Dim x2 = New Integer(numRows) {}
        Dim count As Integer = 0 'Create a variable to keep track of the indices as data is added to the arrays

        'Put the regression table data into the y, x1, and x2 arrays
        While myReader.Read()
            Dim y_String As String = myReader("Y").ToString()
            y(count) = CDbl(y_String)
            Dim x1_String As String = myReader("X1").ToString()
            x1(count) = CInt(x1_String)
            Dim x2_String As String = myReader("X2").ToString()
            x2(count) = CInt(x2_String)
            Dim row As String = y_String & vbTab & x1_String & vbTab & x2_String & vbTab & "Row: " & (count + 1).ToString()
            lstOutput.Items.Add(row)
            count = count + 1
        End While
        myConn.Close()

        Dim n As Integer = numRows
        lstOutput.Items.Add("n is: " & n)

        'Store the sum and average value of y as sumY and avgY
        Dim sumY As Double = CalcSum(y)
        Dim avgY As Double = CalcMean(sumY, n)

        'Store the sum and average value of x1 as sumX1 and avgX1
        Dim sumX1 As Double = CalcSum(x1)
        Dim avgX1 As Double = CalcMean(sumX1, n)

        'Store the sum and average value of x2 as sumX2 and avgX2
        Dim sumX2 As Double = CalcSum(x2)
        Dim avgX2 As Double = CalcMean(sumX2, n)

        'Display the sums and averages of each array
        lstOutput.Items.Add("sumY = " & sumY & " avgY = " & avgY)
        lstOutput.Items.Add("sumX1 = " & sumX1 & " avgX1 = " & avgX1)
        lstOutput.Items.Add("sumX2 = " & sumX2 & " avgx=X2 = " & avgX2)

        'Store and display the sums of squares for y, x1, and x2 as sumSQY, sumSQX1, and sumSQX2 respectively
        Dim sumSQY As Double = CalcSumOfSquares(y)
        Dim sumSQX1 As Double = CalcSumOfSquares(x1)
        Dim sumSQX2 As Double = CalcSumOfSquares(x2)
        lstOutput.Items.Add("Y SQ = " & sumSQY & " X1 SQ = " & sumSQX1 & " x2 SQ = " & sumSQX2)

        'Store and display the sums of products of two arrays from y, x1, and x2 as sumYX1, sumYX2, and sumX1X2 respectively
        Dim sumYX1 As Double = CalcSumOfVar(y, x1)
        Dim sumYX2 As Double = CalcSumOfVar(y, x2)
        Dim sumX1X2 As Double = CalcSumOfVar(x1, x2)
        lstOutput.Items.Add("YX1 = " & sumYX1 & " YX2 = " & sumYX2 & " X1X2 = " & sumX1X2)

        Dim sumy_2 As Double = sumSQY - (Math.Pow(sumY, 2) / n)
        lstOutput.Items.Add(" " & sumy_2)

        Dim sumx1_2 As Double = sumSQX1 - (Math.Pow(sumX1, 2) / n)
        lstOutput.Items.Add(" " & sumx1_2)

        Dim sumx2_2 As Double = sumSQX2 - (Math.Pow(sumX2, 2) / n)
        lstOutput.Items.Add(" " & sumx2_2)

        Dim sumx1y As Double = sumYX1 - ((sumX1 * sumY) / n)
        lstOutput.Items.Add(" " & sumx1y)

        Dim sumx2y As Double = sumYX2 - ((sumX2 * sumY) / n)
        lstOutput.Items.Add(" " & sumx2y)

        Dim sumx1x2_2 As Double = sumX1X2 - ((sumX1 * sumX2) / n)
        lstOutput.Items.Add(" " & sumx1x2_2)

        lstOutput.Items.Add("")
        lstOutput.Items.Add("The regression coefficients are the following:")

        'Store the first linear regression coefficients as b1 and display it
        Dim b1 As Double = (sumx2_2 * sumx1y - sumx1x2_2 * sumx2y) / (sumx1_2 * sumx2_2 - sumx1x2_2 * sumx1x2_2)
        lstOutput.Items.Add("b1 = " & b1)

        'Store the second linear regression coefficients as b2 and display it
        Dim b2 As Double = (sumx1_2 * sumx2y - sumx1x2_2 * sumx1y) / (sumx1_2 * sumx2_2 - sumx1x2_2 * sumx1x2_2)
        lstOutput.Items.Add("b2 = " & b2)

        'Store the linear regression error term as a and display it
        Dim a As Double = avgY - b1 * avgX1 - b2 * avgX2
        lstOutput.Items.Add("a = " & a)

        'Put the regression coefficients into the regression_co SQL table
        myCmd.CommandText = "EXEC pro_reg_co " & b1.ToString() & ", " & b2.ToString() & ", " & a.ToString()
        myConn.Open()
        myReader = myCmd.ExecuteReader()
        myConn.Close()
        Return 0
    End Function

    'This subroutine switches back to the regression calculation form
    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        lstOutput.Items.Clear()

        If Len(txtState.Text) <= 2 And IsNumeric(txtY.Text) And Integer.TryParse(txtX1.Text, vbNull) And Integer.TryParse(txtX2.Text, vbNull) Then
            'CHANGE BELOW LINE FOR CURRENT DEVICE!!
            myConn = New SqlConnection("Data Source = LAPTOP-6G2QDAKE\SQLEXPRESS;
            Initial Catalog = master;
            Integrated Security = SSPI")
            'CHANGE ABOVE LINE FOR CURRENT DEVICE!!

            'Get the data from the text fields which is to be inserted into the regression table
            Dim statename As String = txtState.Text
            Dim y As Double = txtY.Text
            Dim x1 As Integer = txtX1.Text
            Dim x2 As Integer = txtX2.Text

            'Set the unique Boolean to False if the statename entered matches one in the table
            Dim unique As Boolean = True
            myCmd = myConn.CreateCommand
            myCmd.CommandText = "SELECT statename FROM regression"
            myConn.Open()
            myReader = myCmd.ExecuteReader()
            While myReader.Read()
                If statename = myReader("statename").ToString() Then
                    unique = False
                End If
            End While
            myConn.Close()

            'Check if the data can be inserted into the regression table
            If unique Then
                'Insert the stored data into the regression table
                myCmd.CommandText = "EXEC pro_reg_insert '" & statename.ToString() & "', " & y.ToString() & ", " & x1.ToString() & ", " & x2.ToString()
                myConn.Open()
                myReader = myCmd.ExecuteReader()
                myConn.Close()
                lstOutput.Items.Add("The following data was successfully added to the table.")
                lstOutput.Items.Add("Primary Key: " & statename.ToString())
                lstOutput.Items.Add("Y: " & y.ToString())
                lstOutput.Items.Add("X1: " & x1.ToString())
                lstOutput.Items.Add("X2: " & x2.ToString())
                lstOutput.Items.Add("")

                Dim useless As Integer = CalcRegression()
            Else
                lstOutput.Items.Add("The data could not be inserted due to primary key constraint violation.")
            End If
        Else
            lstOutput.Items.Add("The data could not be inserted due to improper formatting")
        End If
    End Sub

    'This subroutine clears the data output displays
    Private Sub btnClearDisplay_Click(sender As Object, e As EventArgs) Handles btnClearDisplay.Click
        lstOutput.Items.Clear()
    End Sub

    'This subroutine switches back to the regression calculation form
    Private Sub btnSeeData_Click(sender As Object, e As EventArgs) Handles btnSeeData.Click
        Me.Hide()
        Form1.Show()
    End Sub

    'This subroutine switches to the regression prediction form
    Private Sub btnMakePredict_Click(sender As Object, e As EventArgs) Handles btnMakePredict.Click
        Me.Hide()
        Form2.Show()
    End Sub

    'This subroutine closes the entire application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
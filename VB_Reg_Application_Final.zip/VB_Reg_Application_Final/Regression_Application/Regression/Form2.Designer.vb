﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtX2 = New System.Windows.Forms.TextBox()
        Me.txtX1 = New System.Windows.Forms.TextBox()
        Me.btnPredict = New System.Windows.Forms.Button()
        Me.btnSeeData = New System.Windows.Forms.Button()
        Me.lstPredict = New System.Windows.Forms.ListBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddData = New System.Windows.Forms.Button()
        Me.btnClearDisplay = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtX2
        '
        Me.txtX2.Location = New System.Drawing.Point(108, 298)
        Me.txtX2.Name = "txtX2"
        Me.txtX2.Size = New System.Drawing.Size(100, 20)
        Me.txtX2.TabIndex = 1
        Me.txtX2.Text = "X2"
        '
        'txtX1
        '
        Me.txtX1.Location = New System.Drawing.Point(108, 272)
        Me.txtX1.Name = "txtX1"
        Me.txtX1.Size = New System.Drawing.Size(100, 20)
        Me.txtX1.TabIndex = 0
        Me.txtX1.Text = "X1"
        '
        'btnPredict
        '
        Me.btnPredict.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPredict.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPredict.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPredict.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPredict.ForeColor = System.Drawing.Color.Blue
        Me.btnPredict.Location = New System.Drawing.Point(108, 12)
        Me.btnPredict.Name = "btnPredict"
        Me.btnPredict.Size = New System.Drawing.Size(75, 25)
        Me.btnPredict.TabIndex = 2
        Me.btnPredict.Text = "Predict"
        Me.btnPredict.UseVisualStyleBackColor = False
        '
        'btnSeeData
        '
        Me.btnSeeData.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSeeData.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSeeData.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSeeData.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeeData.ForeColor = System.Drawing.Color.Blue
        Me.btnSeeData.Location = New System.Drawing.Point(108, 351)
        Me.btnSeeData.Name = "btnSeeData"
        Me.btnSeeData.Size = New System.Drawing.Size(75, 25)
        Me.btnSeeData.TabIndex = 3
        Me.btnSeeData.Text = "See Data"
        Me.btnSeeData.UseVisualStyleBackColor = False
        '
        'lstPredict
        '
        Me.lstPredict.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lstPredict.Cursor = System.Windows.Forms.Cursors.No
        Me.lstPredict.FormattingEnabled = True
        Me.lstPredict.Location = New System.Drawing.Point(108, 41)
        Me.lstPredict.Name = "lstPredict"
        Me.lstPredict.Size = New System.Drawing.Size(450, 225)
        Me.lstPredict.TabIndex = 4
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Red
        Me.btnExit.Location = New System.Drawing.Point(108, 380)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 25)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnAddData
        '
        Me.btnAddData.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnAddData.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAddData.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddData.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddData.ForeColor = System.Drawing.Color.Blue
        Me.btnAddData.Location = New System.Drawing.Point(189, 351)
        Me.btnAddData.Name = "btnAddData"
        Me.btnAddData.Size = New System.Drawing.Size(75, 25)
        Me.btnAddData.TabIndex = 6
        Me.btnAddData.Text = "Add Data"
        Me.btnAddData.UseVisualStyleBackColor = False
        '
        'btnClearDisplay
        '
        Me.btnClearDisplay.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnClearDisplay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClearDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClearDisplay.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearDisplay.ForeColor = System.Drawing.Color.Blue
        Me.btnClearDisplay.Location = New System.Drawing.Point(189, 12)
        Me.btnClearDisplay.Name = "btnClearDisplay"
        Me.btnClearDisplay.Size = New System.Drawing.Size(100, 25)
        Me.btnClearDisplay.TabIndex = 7
        Me.btnClearDisplay.Text = "Clear Dislay"
        Me.btnClearDisplay.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(214, 275)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 15)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "# of Active Interstates in State"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(214, 301)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(200, 15)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Maximum Speed Limit in State (mph)"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClearDisplay)
        Me.Controls.Add(Me.btnAddData)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lstPredict)
        Me.Controls.Add(Me.btnSeeData)
        Me.Controls.Add(Me.btnPredict)
        Me.Controls.Add(Me.txtX2)
        Me.Controls.Add(Me.txtX1)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtX2 As TextBox
    Friend WithEvents txtX1 As TextBox
    Friend WithEvents btnPredict As Button
    Friend WithEvents btnSeeData As Button
    Friend WithEvents lstPredict As ListBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddData As Button
    Friend WithEvents btnClearDisplay As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class

﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar

Public Class Form2
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader

    'This subroutine calculates and displays the predicted Y value
    Private Sub btnPredict_Click(sender As Object, e As EventArgs) Handles btnPredict.Click
        lstPredict.Items.Clear()
        If IsNumeric(txtX1.Text) And IsNumeric(txtX2.Text) Then
            Dim b1 As Double = 0
            Dim b2 As Double = 0
            Dim a As Double = 0
            Dim y As Double = 0

            'CHANGE BELOW LINE FOR CURRENT DEVICE!!
            myConn = New SqlConnection("Data Source = LAPTOP-6G2QDAKE\SQLEXPRESS;
            Initial Catalog = master;
            Integrated Security = SSPI")
            'CHANGE ABOVE LINE FOR CURRENT DEVICE!!

            myCmd = myConn.CreateCommand
            myCmd.CommandText = "select b1,b2,a from Regression_co"
            myConn.Open()
            myReader = myCmd.ExecuteReader()

            While myReader.Read()
                Dim b1_String As String = myReader("B1").ToString()
                b1 = CDbl(b1_String)
                Dim b2_String As String = myReader("B2").ToString()
                b2 = CDbl(b2_String)
                Dim a_String As String = myReader("A").ToString()
                a = CDbl(a_String)
                Dim row As String = "b1: " & b1_String & vbTab & "b2: " & b2_String & vbTab & "a: " & a_String
                lstPredict.Items.Add(row)
                y = a + (b1 * txtX1.Text) + (b2 * txtX2.Text)
                lstPredict.Items.Add("Y: " & Math.Round(y, 2))
                lstPredict.Items.Add("Fatal Car Accidents: " & (Math.Round(y, 2) * 100))
            End While
        Else
            lstPredict.Items.Add("Invalid Inputs!")
        End If
    End Sub

    'This subroutine clears the data output displays
    Private Sub btnClearDisplay_Click(sender As Object, e As EventArgs) Handles btnClearDisplay.Click
        lstPredict.Items.Clear()
    End Sub

    'This subroutine switches back to the regression calculation form
    Private Sub btnSeeData_Click(sender As Object, e As EventArgs) Handles btnSeeData.Click
        Me.Hide()
        Form1.Show()
    End Sub

    'This subroutine switches to the form for adding data to the regression table
    Private Sub btnAddData_Click(sender As Object, e As EventArgs) Handles btnAddData.Click
        Me.Hide()
        Form3.Show()
    End Sub

    'This subroutine closes the entire application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
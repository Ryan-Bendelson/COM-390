﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSeeData = New System.Windows.Forms.Button()
        Me.txtX1 = New System.Windows.Forms.TextBox()
        Me.txtX2 = New System.Windows.Forms.TextBox()
        Me.txtY = New System.Windows.Forms.TextBox()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.btnMakePredict = New System.Windows.Forms.Button()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.btnClearDisplay = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Red
        Me.btnExit.Location = New System.Drawing.Point(108, 380)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 25)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSeeData
        '
        Me.btnSeeData.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSeeData.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSeeData.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSeeData.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeeData.ForeColor = System.Drawing.Color.Blue
        Me.btnSeeData.Location = New System.Drawing.Point(108, 351)
        Me.btnSeeData.Name = "btnSeeData"
        Me.btnSeeData.Size = New System.Drawing.Size(75, 25)
        Me.btnSeeData.TabIndex = 1
        Me.btnSeeData.Text = "See Data"
        Me.btnSeeData.UseVisualStyleBackColor = False
        '
        'txtX1
        '
        Me.txtX1.Location = New System.Drawing.Point(108, 259)
        Me.txtX1.Name = "txtX1"
        Me.txtX1.Size = New System.Drawing.Size(100, 20)
        Me.txtX1.TabIndex = 2
        Me.txtX1.Text = "X1"
        '
        'txtX2
        '
        Me.txtX2.Location = New System.Drawing.Point(108, 285)
        Me.txtX2.Name = "txtX2"
        Me.txtX2.Size = New System.Drawing.Size(100, 20)
        Me.txtX2.TabIndex = 3
        Me.txtX2.Text = "X2"
        '
        'txtY
        '
        Me.txtY.Location = New System.Drawing.Point(108, 233)
        Me.txtY.Name = "txtY"
        Me.txtY.Size = New System.Drawing.Size(100, 20)
        Me.txtY.TabIndex = 4
        Me.txtY.Text = "Y"
        '
        'lstOutput
        '
        Me.lstOutput.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lstOutput.Cursor = System.Windows.Forms.Cursors.No
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.Location = New System.Drawing.Point(108, 41)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(450, 160)
        Me.lstOutput.TabIndex = 5
        '
        'btnInsert
        '
        Me.btnInsert.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnInsert.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInsert.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsert.ForeColor = System.Drawing.Color.Blue
        Me.btnInsert.Location = New System.Drawing.Point(108, 12)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(75, 25)
        Me.btnInsert.TabIndex = 6
        Me.btnInsert.Text = "Insert Data"
        Me.btnInsert.UseVisualStyleBackColor = False
        '
        'btnMakePredict
        '
        Me.btnMakePredict.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnMakePredict.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMakePredict.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMakePredict.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMakePredict.ForeColor = System.Drawing.Color.Blue
        Me.btnMakePredict.Location = New System.Drawing.Point(189, 351)
        Me.btnMakePredict.Name = "btnMakePredict"
        Me.btnMakePredict.Size = New System.Drawing.Size(200, 25)
        Me.btnMakePredict.TabIndex = 7
        Me.btnMakePredict.Text = "Make Prediction"
        Me.btnMakePredict.UseVisualStyleBackColor = False
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(108, 207)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(100, 20)
        Me.txtState.TabIndex = 8
        Me.txtState.Text = "State Name"
        '
        'btnClearDisplay
        '
        Me.btnClearDisplay.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnClearDisplay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClearDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClearDisplay.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearDisplay.ForeColor = System.Drawing.Color.Blue
        Me.btnClearDisplay.Location = New System.Drawing.Point(189, 12)
        Me.btnClearDisplay.Name = "btnClearDisplay"
        Me.btnClearDisplay.Size = New System.Drawing.Size(100, 25)
        Me.btnClearDisplay.TabIndex = 9
        Me.btnClearDisplay.Text = "Clear Display"
        Me.btnClearDisplay.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(214, 261)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 15)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "# of Active Interstates in State"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(214, 287)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(200, 15)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Maximum Speed Limit in State (mph)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(214, 238)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(298, 15)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Hundreds of Fatal Car Accidents in State Within a Year"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(214, 209)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(218, 15)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "State Abbreviation (ex: AL for Alabama)"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClearDisplay)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.btnMakePredict)
        Me.Controls.Add(Me.btnInsert)
        Me.Controls.Add(Me.lstOutput)
        Me.Controls.Add(Me.txtY)
        Me.Controls.Add(Me.txtX2)
        Me.Controls.Add(Me.txtX1)
        Me.Controls.Add(Me.btnSeeData)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSeeData As Button
    Friend WithEvents txtX1 As TextBox
    Friend WithEvents txtX2 As TextBox
    Friend WithEvents txtY As TextBox
    Friend WithEvents lstOutput As ListBox
    Friend WithEvents btnInsert As Button
    Friend WithEvents btnMakePredict As Button
    Friend WithEvents txtState As TextBox
    Friend WithEvents btnClearDisplay As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class

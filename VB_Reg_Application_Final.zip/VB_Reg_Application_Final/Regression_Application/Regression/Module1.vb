﻿Imports System.Data.SqlClient
Module Module1
    'Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader

    'This function takes in a sum of numbers and the amount of numbers summed to get an average which is returned
    Public Function CalcMean(sum As Double, N As Integer)
        Dim avg As Double = sum / N
        Return avg
    End Function

    'This function calculates the sum of an array of numbers and returns it
    Public Function CalcSum(nums) As Double
        Dim sum As Double = 0
        For index As Integer = 0 To nums.Length - 1
            sum = sum + nums(index)
        Next
        Return sum
    End Function

    'This function calculates the sum of squares of numbers from an array and returns it
    Public Function CalcSumOfSquares(nums) As Double
        Dim sum As Double = 0
        For index As Integer = 0 To nums.Length - 1
            sum = sum + (nums(index) ^ 2)
        Next
        Return sum
    End Function

    'This function sums the products of two arrays
    Public Function CalcSumOfVar(nums1, nums2)
        Dim sum As Double = 0
        For index As Integer = 0 To nums1.Length - 1
            sum = sum + (nums1(index) * nums2(index))
        Next
        Return sum
    End Function

    'This function returns the number of rows in the regression table
    Public Function GetNumRows() As Integer
        'CHANGE BELOW LINE FOR CURRENT DEVICE!!
        myConn = New SqlConnection("Data Source = LAPTOP-6G2QDAKE\SQLEXPRESS;
        Initial Catalog = master;
        Integrated Security = SSPI")
        'CHANGE ABOVE LINE FOR CURRENT DEVICE!!

        'Store the number of rows in the regression table as numRows
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "EXEC pro_reg_count"
        myConn.Open()
        myReader = myCmd.ExecuteReader()
        Dim numRows As Integer = 0
        While myReader.Read()
            numRows = CInt(myReader("count").ToString())
        End While
        myConn.Close()

        Return numRows 'Return numRows
    End Function
End Module
